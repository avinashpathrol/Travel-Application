// const express = require('express');
// const router = express.Router();
// const { getCoordinatesByCityName } = require('../controllers/geocodeController');
// const { getWeatherByCityName } = require('../controllers/weatherController'); // Assuming this is defined

// // Geocoding route
// router.get('/direct', getCoordinatesByCityName);

// // Fetch weather by city name
// router.get('/by-city', getWeatherByCityName);

// module.exports = router;
